Welcome to the node-gyp wiki!

 * [["binding.gyp" files out in the wild]]
 * [[Linking to OpenSSL]]
 * [[Common Issues]]
 * [[Updating npm's bundled node-gyp]]
 * [[Error: "pre" versions of node cannot be installed]]
